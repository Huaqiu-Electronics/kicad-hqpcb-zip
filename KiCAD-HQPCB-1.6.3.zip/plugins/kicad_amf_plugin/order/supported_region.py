class SupportedRegion:
    CHINA_MAINLAND = 0
    EUROPE_USA = 1
    JAPAN = 2
