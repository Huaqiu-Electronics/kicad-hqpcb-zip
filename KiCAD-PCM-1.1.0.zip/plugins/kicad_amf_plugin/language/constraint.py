# language domain
LANG_DOMAIN = "kicad_amf_plugin"


ENGLISH = "English"

DEFAULT_LANG = ENGLISH


CODE_TO_NAME = {"en": "English", "ja": "Japanese", "zh_CN": "Chinese"}
