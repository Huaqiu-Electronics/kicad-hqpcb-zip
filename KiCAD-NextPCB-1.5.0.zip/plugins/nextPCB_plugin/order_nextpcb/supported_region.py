class SupportedRegion:
    EUROPE_USA = 0
    JAPAN = 1
    CHINA_MAINLAND = 2
