import wx
import wx.xrc
import wx.dataview
import requests
import json
import webbrowser
import io

from .ui_assigned_part_panel import UiAssignedPartPanel
import wx.dataview as dv
from kicad_amf_plugin.kicad_nextpcb_new.helpers import loadBitmapScaled

parameters = {
    "mpn": _("MPN"),
    "manufacturer": _("Manufacturer"),
    "pkg": _("Package / Footprint"),
    "category": _("Category"),
    "part_desc": _("Description"),
}
attribute_para = {
    "sku": _("SKU"),
    # "vendor": _("Supplier"),
    # "quantity": _("Stock"),
}


class AssignedPartView(UiAssignedPartPanel):
    def __init__(
        self,
        parent,
        id=wx.ID_ANY,
        pos=wx.DefaultPosition,
        size=wx.DefaultSize,
        style=wx.TAB_TRAVERSAL,
        name=wx.EmptyString,
    ):
        super().__init__(parent, id=id, pos=pos, size=size, style=style, name=name)

        # ---------------------------------------------------------------------
        # ----------------------- Properties List -----------------------------
        # ---------------------------------------------------------------------
        self.property = self.data_list.AppendTextColumn(
            _("Property"),
            width=160,
            mode=dv.DATAVIEW_CELL_ACTIVATABLE,
            align=wx.ALIGN_LEFT,
        )
        self.value = self.data_list.AppendTextColumn(
            _("Value"), width=-1, mode=dv.DATAVIEW_CELL_ACTIVATABLE, align=wx.ALIGN_LEFT
        )
        self.initialize_data()

    def initialize_data(self):
        # Initialize data and populate the data list
        self.data_list.DeleteAllItems()
        self.part_image.SetBitmap(wx.NullBitmap)

        for k, v in parameters.items():
            self.data_list.AppendItem([v, " "])
        for k, v in attribute_para.items():
            self.data_list.AppendItem([v, " "])
        # self.data_list.AppendItem([_("Price"), " "])
        self.data_list.AppendItem([_("Datasheet"), " "])
        # update layout
        self.Layout()

    def on_open_pdf(self, e):
        """Open the linked datasheet PDF on button click."""
        item = self.data_list.GetSelection()
        row = self.data_list.ItemToRow(item)
        Datasheet = self.data_list.GetTextValue(row, 0)
        if self.pdfurl != "-" and Datasheet == "Datasheet":
            self.logger.info("opening %s", str(self.pdfurl))
            webbrowser.open("https:" + self.pdfurl)

    def get_scaled_bitmap(self, url):
        """Download a picture from a URL and convert it into a wx Bitmap"""
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.9999.999 Safari/537.36"
        }
        content = requests.get(url, headers=header).content
        io_bytes = io.BytesIO(content)
        image = wx.Image(io_bytes, type=wx.BITMAP_TYPE_ANY)
        result = wx.Bitmap(image)
        return result

    def get_part_data(self, selected_part):
        """fetch part data from NextPCB API and parse it into the table, set picture and PDF link"""
        if selected_part == "":
            self.report_part_data_fetch_error(
                _("returned data does not have expected part details")
            )
        self.info = selected_part.get("part_info", {})
        self.suppliers = selected_part.get("supplier_chain", {})

        for i in range(self.data_list.GetItemCount()):
            self.data_list.DeleteItem(0)
        for k, v in parameters.items():
            val = self.info.get(k, "-")
            if val != "null" and val:
                self.data_list.AppendItem([v, str(val)])
            else:
                self.data_list.AppendItem([v, "-"])

        # judge whether supplier chain data is available
        for k, v in attribute_para.items():
            val = "-"
            if self.suppliers != []:
                for supplier_chain  in self.suppliers:
                    vendor = supplier_chain.get("vendor", {})
                    if vendor == "hqself":
                        val = supplier_chain.get(k, "-")
            self.data_list.AppendItem([v, str(val)])

        self.pdfurl = self.info.get("datasheet", {})
        self.pdfurl = "-" if self.pdfurl == "" else self.pdfurl
        self.data_list.AppendItem(
            [
                _("Datasheet"),
                self.pdfurl,
            ]
        )
        self.data_list.Bind(wx.dataview.EVT_DATAVIEW_ITEM_ACTIVATED, self.on_open_pdf)
        picture = self.info.get("image", [])
        if picture:
            self.part_image.SetBitmap(
                self.get_scaled_bitmap(
                    picture,
                )
            )
        else:
            self.part_image.SetBitmap(wx.NullBitmap)
        self.Layout()

    def report_part_data_fetch_error(self, reason):
        wx.MessageBox(
            _(f"Failed to download part detail from the NextPCB API ({reason})\r\n"),
            _("Error"),
            style=wx.ICON_ERROR,
        )
        self.Destroy()
