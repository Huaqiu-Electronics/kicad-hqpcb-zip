if __name__ == "__main__":
    from kicad_amf_plugin.plugin._main import _main

    _main()
