class SupportedRegion:
    CHINA_MAINLAND = 0
    JAPAN = 1
    EUROPE_USA = 2
