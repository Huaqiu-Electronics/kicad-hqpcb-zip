DEFAULT_EXPRESS = {"address": "广东省深圳市", "express": "顺丰快递"}
