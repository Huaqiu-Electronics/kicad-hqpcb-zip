DEFAULT_EXPRESS = {"address": "广东省深圳市", "express": "顺丰快递"}

ALLOWED_KEYS =  ["pcb_ban_width", "pcb_ban_height", "number", "single_or_double_technique", "bom_material_type_number", 
                 "patch_pad_number", "is_plug", "plug_number", "need_split", "need_conformal_coating", "x_ray_number" , 
                 "x_ray_unit_number", "is_test", "steel_type" , "packing_type"] 

ADDED_DATA = { "plug_material_type": 1 }