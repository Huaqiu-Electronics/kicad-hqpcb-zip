import wx

_ = wx.GetTranslation


BOOLEAN_CHOICE = [_("No"), _("Yes")]
